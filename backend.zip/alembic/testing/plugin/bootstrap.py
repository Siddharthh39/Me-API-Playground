"""
Bootstrapper for test framework plugins.

"""
